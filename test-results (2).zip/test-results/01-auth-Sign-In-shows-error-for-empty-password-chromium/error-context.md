# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Sign In >> shows error for empty password
- Location: e2e\01-auth.spec.ts:64:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[data-sonner-toast]').or(locator('[role="status"]')).or(locator('[class*="toast"]')).filter({ hasText: /email|password|required/i }).first()
Expected: visible
Timeout: 8000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 8000ms
  - waiting for locator('[data-sonner-toast]').or(locator('[role="status"]')).or(locator('[class*="toast"]')).filter({ hasText: /email|password|required/i }).first()

```

```yaml
- region "Notifications (F8)":
  - list
- region "Notifications alt+T"
- img
- heading "CA Munim" [level=1]
- paragraph: Your digital practice manager
- button "Sign In"
- button "Create Account"
- text: Email Address
- textbox "Email Address":
  - /placeholder: you@yourfirm.com
  - text: sonusingh1590@gmail.com
- text: Password
- textbox "Password":
  - /placeholder: Your password
- button:
  - img
- button "Sign In"
- text: or continue with
- button "Continue with Google":
  - img
  - text: Continue with Google
- button "Forgot password?"
- paragraph: Your data is secured with row-level encryption. © 2026 CA Munim
```

# Test source

```ts
  1   | /**
  2   |  * e2e/helpers/auth.ts
  3   |  * Resilient selectors — works regardless of exact label/button text
  4   |  */
  5   | import { Page, expect } from '@playwright/test';
  6   | 
  7   | export const TEST_USER = {
  8   |   email: process.env.TEST_USER_EMAIL ?? 'sonusingh1590@gmail.com',
  9   |   password: process.env.TEST_USER_PASSWORD ?? 'Camunim#1590',
  10  | };
  11  | 
  12  | export const TEST_CLIENT = {
  13  |   name: 'Playwright Test Client',
  14  |   pan: 'ABCPT1234K',
  15  |   phone: '9876543210',
  16  |   email: 'testclient@playwright.test',
  17  |   city: 'Pune',
  18  |   state: 'Maharashtra',
  19  |   type: 'Individual',
  20  | };
  21  | 
  22  | export const TEST_CLIENT_2 = {
  23  |   name: 'Playwright Firm Test',
  24  |   pan: 'AABCP5678M',
  25  |   phone: '9123456789',
  26  |   email: 'firmtest@playwright.test',
  27  |   city: 'Mumbai',
  28  |   state: 'Maharashtra',
  29  |   type: 'Private Ltd',
  30  | };
  31  | 
  32  | export const TEST_TASK = {
  33  |   type: 'GSTR-3B',
  34  |   financialYear: 'FY 2025-26',
  35  |   period: 'April',
  36  |   priority: 'high',
  37  | };
  38  | 
  39  | export const TEST_INVOICE = {
  40  |   description: 'ITR Filing FY 2025-26',
  41  |   amount: '5000',
  42  | };
  43  | 
  44  | export async function signIn(
  45  |   page: Page,
  46  |   email = TEST_USER.email,
  47  |   password = TEST_USER.password
  48  | ) {
  49  |   await page.goto('/login');
  50  |   await expect(page.getByText('CA Munim').first()).toBeVisible({ timeout: 10_000 });
  51  | 
  52  |   // Switch to Sign In tab if needed
  53  |   const signInTab = page.getByRole('button', { name: /^sign.?in$/i }).first();
  54  |   if (await signInTab.isVisible()) await signInTab.click();
  55  | 
  56  |   // Fill email — try multiple selector strategies
  57  |   const emailInput = page.locator('input[type="email"]').first();
  58  |   await emailInput.fill(email);
  59  | 
  60  |   // Fill password
  61  |   const passwordInput = page.locator('input[type="password"]').first();
  62  |   await passwordInput.fill(password);
  63  | 
  64  |   // Click sign in button
  65  |   await page.getByRole('button', { name: /sign.?in/i }).click();
  66  | 
  67  |   // Wait for redirect away from /login
  68  |   await expect(page).not.toHaveURL('/login', { timeout: 15_000 });
  69  | }
  70  | 
  71  | export async function signOut(page: Page) {
  72  |   const logoutBtn = page.locator('[title="Sign out"]')
  73  |     .or(page.getByRole('button', { name: /sign.?out|log.?out/i }))
  74  |     .first();
  75  |   await logoutBtn.click();
  76  |   await expect(page).toHaveURL('/login', { timeout: 8_000 });
  77  | }
  78  | 
  79  | export async function expectToast(page: Page, text: string | RegExp, timeout = 8_000) {
  80  |   const toast = page.locator('[data-sonner-toast]')
  81  |     .or(page.locator('[role="status"]'))
  82  |     .or(page.locator('[class*="toast"]'))
  83  |     .filter({ hasText: text })
  84  |     .first();
> 85  |   await expect(toast).toBeVisible({ timeout });
      |                       ^ Error: expect(locator).toBeVisible() failed
  86  | }
  87  | 
  88  | export async function waitForLoading(page: Page, timeout = 15_000) {
  89  |   try {
  90  |     await page.locator('.animate-spin').first().waitFor({ state: 'hidden', timeout });
  91  |   } catch {
  92  |     // spinner never appeared — that's fine
  93  |   }
  94  | }
  95  | 
  96  | export async function openModal(page: Page, triggerText: string): Promise<void> {
  97  |   await page.getByRole('button', { name: new RegExp(triggerText, 'i') }).first().click();
  98  |   await expect(page.getByRole('dialog')).toBeVisible({ timeout: 5_000 });
  99  | }
  100 | 
  101 | export async function closeModal(page: Page): Promise<void> {
  102 |   const cancelBtn = page.getByRole('dialog').getByRole('button', { name: /cancel|close/i }).first();
  103 |   if (await cancelBtn.isVisible()) {
  104 |     await cancelBtn.click();
  105 |   } else {
  106 |     await page.keyboard.press('Escape');
  107 |   }
  108 |   await expect(page.getByRole('dialog')).not.toBeVisible({ timeout: 5_000 });
  109 | }
  110 | 
  111 | export async function selectByPlaceholder(page: Page, placeholder: string, optionText: string) {
  112 |   await page.getByText(placeholder, { exact: false }).first().click();
  113 |   await page.getByRole('option', { name: new RegExp(optionText, 'i') }).first().click();
  114 | }
```