# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Sign In >> shows login page with correct elements
- Location: e2e\01-auth.spec.ts:25:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Sign In')
Expected: visible
Error: strict mode violation: getByText('Sign In') resolved to 2 elements:
    1) <button type="button" class="flex-1 text-sm font-medium py-1.5 rounded-md transition-colors bg-primary text-primary-foreground">Sign In</button> aka getByRole('button', { name: 'Sign In' }).first()
    2) <button type="submit" class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 px-4 py-2 w-full h-11 bg-accent hover:bg-accent/90 text-white font-semibold">Sign In</button> aka locator('form').getByRole('button', { name: 'Sign In' })

Call log:
  - Expect "toBeVisible" with timeout 8000ms
  - waiting for getByText('Sign In')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications (F8)":
    - list
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "CA Munim" [level=1] [ref=e11]
      - paragraph [ref=e12]: Your digital practice manager
    - generic [ref=e13]:
      - generic [ref=e14]:
        - button "Sign In" [ref=e15] [cursor=pointer]
        - button "Create Account" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]:
          - text: Email Address
          - textbox "Email Address" [ref=e19]:
            - /placeholder: you@yourfirm.com
        - generic [ref=e20]:
          - text: Password
          - generic [ref=e21]:
            - textbox "Password" [ref=e22]:
              - /placeholder: Your password
            - button [ref=e23] [cursor=pointer]:
              - img [ref=e24]
        - button "Sign In" [ref=e27] [cursor=pointer]
      - generic [ref=e28]: or continue with
      - button "Continue with Google" [ref=e29] [cursor=pointer]:
        - img
        - text: Continue with Google
      - button "Forgot password?" [ref=e30] [cursor=pointer]
    - paragraph [ref=e31]:
      - text: Your data is secured with row-level encryption.
      - text: © 2026 CA Munim
```

# Test source

```ts
  1   | /**
  2   |  * e2e/01-auth.spec.ts
  3   |  * 
  4   |  * Tests all authentication flows:
  5   |  * - Sign up (happy + negative paths)
  6   |  * - Sign in (happy + negative paths)
  7   |  * - Onboarding (firm + solo practitioner)
  8   |  * - Session persistence on refresh
  9   |  * - Sign out
  10  |  * - Protected route redirect
  11  |  * - Forgot password
  12  |  */
  13  | 
  14  | import { test, expect } from '@playwright/test';
  15  | import { signIn, signOut, expectToast, TEST_USER } from './helpers/auth';
  16  | 
  17  | // ── Sign In ──────────────────────────────────────────────────────────────────
  18  | 
  19  | test.describe('Sign In', () => {
  20  |   test.beforeEach(async ({ page }) => {
  21  |     await page.goto('/login');
  22  |     await expect(page.getByText('CA Munim').first()).toBeVisible();
  23  |   });
  24  | 
  25  |   test('shows login page with correct elements', async ({ page }) => {
> 26  |     await expect(page.getByText('Sign In')).toBeVisible();
      |                                             ^ Error: expect(locator).toBeVisible() failed
  27  |     await expect(page.getByText('Create Account')).toBeVisible();
  28  |     await expect(page.getByLabel('Email Address')).toBeVisible();
  29  |     await expect(page.getByLabel('Password')).toBeVisible();
  30  |     await expect(page.locator('form').getByRole('button', {name: /^sign in$/i,})).toBeVisible();
  31  |     await expect(page.getByText('Forgot password?')).toBeVisible();
  32  |   });
  33  | 
  34  |   test('signs in with valid credentials', async ({ page }) => {
  35  |     await signIn(page);
  36  |     await expect(page).toHaveURL('/');
  37  |   });
  38  | 
  39  |   test('shows error for wrong password', async ({ page }) => {
  40  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  41  |     await page.getByLabel('Password').fill('WrongPassword123!');
  42  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  43  |     await expectToast(page, /incorrect|invalid|wrong|credentials/i);
  44  |     // Must stay on login page
  45  |     await expect(page).toHaveURL('/login');
  46  |   });
  47  | 
  48  |   test('shows error for invalid email format', async ({ page }) => {
  49  |     await page.getByLabel('Email Address').fill('notanemail');
  50  |     await page.getByLabel('Password').fill('SomePassword123');
  51  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  52  |     // Browser native validation or toast
  53  |     const emailInput = page.getByLabel('Email Address');
  54  |     const validationMessage = await emailInput.evaluate((el: HTMLInputElement) => el.validationMessage);
  55  |     expect(validationMessage).toBeTruthy(); // browser validates email format
  56  |   });
  57  | 
  58  |   test('shows error for empty email', async ({ page }) => {
  59  |     await page.getByLabel('Password').fill('SomePassword123');
  60  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  61  |     await expectToast(page, /email|password|required/i);
  62  |   });
  63  | 
  64  |   test('shows error for empty password', async ({ page }) => {
  65  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  66  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  67  |     await expectToast(page, /email|password|required/i);
  68  |   });
  69  | 
  70  |   test('shows loading state while signing in', async ({ page }) => {
  71  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  72  |     await page.getByLabel('Password').fill(TEST_USER.password);
  73  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  74  |     // Button should show loading state briefly
  75  |     const button = page.getByRole('button', { name: /sign in|signing/i });
  76  |     // Either shows a spinner or disables
  77  |     await expect(button).toBeDisabled().catch(() => {}); // may be too fast
  78  |   });
  79  | 
  80  |   test.skip('unverified email shows helpful error with resend option', async ({ page }) => {
  81  |     // This test requires a known unverified email in your test environment
  82  |     // If Supabase email verification is disabled, skip this
  83  |     await page.getByLabel('Email Address').fill('unverified@test.com');
  84  |     await page.getByLabel('Password').fill('TestPass123!');
  85  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  86  |     await expectToast(page, /verify|confirm|email/i);
  87  |     // Should offer resend option
  88  |     await expect(page.getByRole('button', { name: /resend/i })).toBeVisible();
  89  |   });
  90  | 
  91  |   test.skip('redirects to original page after login', async ({ page }) => {
  92  |     // Try to access a protected route
  93  |     await page.goto('/clients');
  94  |     // Should redirect to login
  95  |     await expect(page).toHaveURL('/login');
  96  |     // Sign in
  97  |     await signIn(page);
  98  |     // Note: redirects to / not /clients in current implementation
  99  |     // Update this if redirect-after-login is implemented
  100 |     await expect(page).toHaveURL(/\//);
  101 |   });
  102 | 
  103 |   test.skip('already logged-in user is redirected away from login', async ({ page }) => {
  104 |     await signIn(page);
  105 |     await page.goto('/login');
  106 |     // Should redirect to dashboard, not show login page
  107 |     await expect(page).toHaveURL('/');
  108 |   });
  109 | });
  110 | 
  111 | // ── Sign Up ──────────────────────────────────────────────────────────────────
  112 | 
  113 | test.describe('Sign Up', () => {
  114 |   test.beforeEach(async ({ page }) => {
  115 |     await page.goto('/login');
  116 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).first().click();
  117 |   });
  118 | 
  119 |   test('shows create account form elements', async ({ page }) => {
  120 |     await expect(page.getByLabel('Email Address')).toBeVisible();
  121 |     await expect(page.getByLabel('Password')).toBeVisible();
  122 |     await expect(page.locator('form').getByRole('button', { name: /^create account$/i })).toBeVisible();
  123 |   });
  124 | 
  125 |   test('shows error for password too short', async ({ page }) => {
  126 |     await page.getByLabel('Email Address').fill('newuser@test.com');
```