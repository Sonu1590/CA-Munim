# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Sign Up >> valid signup redirects to onboarding
- Location: e2e\01-auth.spec.ts:146:3

# Error details

```
Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Create Account' }) resolved to 2 elements:
    1) <button type="button" class="flex-1 text-sm font-medium py-1.5 rounded-md transition-colors bg-primary text-primary-foreground">Create Account</button> aka getByRole('button', { name: 'Create Account' }).first()
    2) <button type="submit" class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 px-4 py-2 w-full h-11 bg-accent hover:bg-accent/90 text-white font-semibold">Create Account</button> aka locator('form').getByRole('button', { name: 'Create Account' })

Call log:
  - waiting for getByRole('button', { name: 'Create Account' })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications (F8)":
    - list
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "CA Munim" [level=1] [ref=e11]
      - paragraph [ref=e12]: Your digital practice manager
    - generic [ref=e13]:
      - generic [ref=e14]:
        - button "Sign In" [ref=e15] [cursor=pointer]
        - button "Create Account" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]:
          - text: Your Name *
          - textbox "Your Name *" [ref=e19]:
            - /placeholder: CA Priya Sharma
        - generic [ref=e20]:
          - text: Firm Name
          - textbox "Firm Name" [ref=e21]:
            - /placeholder: Sharma & Associates
        - generic [ref=e22]:
          - text: ICAI Membership Number
          - textbox "ICAI Membership Number" [ref=e23]:
            - /placeholder: "123456"
        - generic [ref=e24]:
          - text: Email Address
          - textbox "Email Address" [ref=e25]:
            - /placeholder: you@yourfirm.com
            - text: test-1780929430129@playwright-ca.test
        - generic [ref=e26]:
          - text: Password
          - generic [ref=e27]:
            - textbox "Password" [active] [ref=e28]:
              - /placeholder: Min. 8 characters
              - text: ValidPass@123
            - button [ref=e29] [cursor=pointer]:
              - img [ref=e30]
        - button "Create Account" [ref=e33] [cursor=pointer]
      - generic [ref=e34]: or continue with
      - button "Continue with Google" [ref=e35] [cursor=pointer]:
        - img
        - text: Continue with Google
    - paragraph [ref=e36]:
      - text: Your data is secured with row-level encryption.
      - text: © 2026 CA Munim
```

# Test source

```ts
  52  |     await page.getByRole('button', { name: 'Sign In' }).click();
  53  |     // Browser native validation or toast
  54  |     const emailInput = page.getByLabel('Email Address');
  55  |     const validationMessage = await emailInput.evaluate((el: HTMLInputElement) => el.validationMessage);
  56  |     expect(validationMessage).toBeTruthy(); // browser validates email format
  57  |   });
  58  | 
  59  |   test('shows error for empty email', async ({ page }) => {
  60  |     await page.getByLabel('Password').fill('SomePassword123');
  61  |     await page.getByRole('button', { name: 'Sign In' }).click();
  62  |     await expectToast(page, /email|password|required/i);
  63  |   });
  64  | 
  65  |   test('shows error for empty password', async ({ page }) => {
  66  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  67  |     await page.getByRole('button', { name: 'Sign In' }).click();
  68  |     await expectToast(page, /email|password|required/i);
  69  |   });
  70  | 
  71  |   test('shows loading state while signing in', async ({ page }) => {
  72  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  73  |     await page.getByLabel('Password').fill(TEST_USER.password);
  74  |     await page.getByRole('button', { name: 'Sign In' }).click();
  75  |     // Button should show loading state briefly
  76  |     const button = page.getByRole('button', { name: /sign in|signing/i });
  77  |     // Either shows a spinner or disables
  78  |     await expect(button).toBeDisabled().catch(() => {}); // may be too fast
  79  |   });
  80  | 
  81  |   test('unverified email shows helpful error with resend option', async ({ page }) => {
  82  |     // This test requires a known unverified email in your test environment
  83  |     // If Supabase email verification is disabled, skip this
  84  |     test.skip(process.env.SUPABASE_EMAIL_VERIFICATION !== 'true', 
  85  |       'Email verification not enabled in this environment');
  86  |     
  87  |     await page.getByLabel('Email Address').fill('unverified@test.com');
  88  |     await page.getByLabel('Password').fill('TestPass123!');
  89  |     await page.getByRole('button', { name: 'Sign In' }).click();
  90  |     await expectToast(page, /verify|confirm|email/i);
  91  |     // Should offer resend option
  92  |     await expect(page.getByRole('button', { name: /resend/i })).toBeVisible();
  93  |   });
  94  | 
  95  |   test('redirects to original page after login', async ({ page }) => {
  96  |     // Try to access a protected route
  97  |     await page.goto('/clients');
  98  |     // Should redirect to login
  99  |     await expect(page).toHaveURL('/login');
  100 |     // Sign in
  101 |     await signIn(page);
  102 |     // Note: redirects to / not /clients in current implementation
  103 |     // Update this if redirect-after-login is implemented
  104 |     await expect(page).toHaveURL(/\//);
  105 |   });
  106 | 
  107 |   test('already logged-in user is redirected away from login', async ({ page }) => {
  108 |     await signIn(page);
  109 |     await page.goto('/login');
  110 |     // Should redirect to dashboard, not show login page
  111 |     await expect(page).toHaveURL('/');
  112 |   });
  113 | });
  114 | 
  115 | // ── Sign Up ──────────────────────────────────────────────────────────────────
  116 | 
  117 | test.describe('Sign Up', () => {
  118 |   test.beforeEach(async ({ page }) => {
  119 |     await page.goto('/login');
  120 |     await page.getByText('Create Account').click();
  121 |   });
  122 | 
  123 |   test('shows create account form elements', async ({ page }) => {
  124 |     await expect(page.getByLabel('Email Address')).toBeVisible();
  125 |     await expect(page.getByLabel('Password')).toBeVisible();
  126 |     await expect(page.getByRole('button', { name: 'Create Account' })).toBeVisible();
  127 |   });
  128 | 
  129 |   test('shows error for password too short', async ({ page }) => {
  130 |     await page.getByLabel('Email Address').fill('newuser@test.com');
  131 |     await page.getByLabel('Password').fill('short');
  132 |     await page.getByRole('button', { name: 'Create Account' }).click();
  133 |     await expectToast(page, /8 character|password.*short|too short/i);
  134 |   });
  135 | 
  136 |   test('shows error for duplicate email', async ({ page }) => {
  137 |     // Try to sign up with an already-registered email
  138 |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  139 |     await page.getByLabel('Password').fill('TestPassword@123');
  140 |     await page.getByRole('button', { name: 'Create Account' }).click();
  141 |     await expectToast(page, /already|exists|registered/i);
  142 |     // Must stay on login page
  143 |     await expect(page).toHaveURL('/login');
  144 |   });
  145 | 
  146 |   test('valid signup redirects to onboarding', async ({ page }) => {
  147 |     // Use a timestamp-based unique email to avoid conflicts
  148 |     const uniqueEmail = `test-${Date.now()}@playwright-ca.test`;
  149 |     
  150 |     await page.getByLabel('Email Address').fill(uniqueEmail);
  151 |     await page.getByLabel('Password').fill('ValidPass@123');
> 152 |     await page.getByRole('button', { name: 'Create Account' }).click();
      |                                                                ^ Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Create Account' }) resolved to 2 elements:
  153 | 
  154 |     // Should go to onboarding
  155 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  156 |     await expect(page.getByText('Welcome to CA Munim')).toBeVisible();
  157 |   });
  158 | });
  159 | 
  160 | // ── Onboarding ───────────────────────────────────────────────────────────────
  161 | 
  162 | test.describe('Onboarding — CA Firm flow', () => {
  163 |   test('completes CA Firm onboarding', async ({ page }) => {
  164 |     // Sign up fresh user
  165 |     const email = `firm-test-${Date.now()}@playwright-ca.test`;
  166 |     await page.goto('/login');
  167 |     await page.getByText('Create Account').click();
  168 |     await page.getByLabel('Email Address').fill(email);
  169 |     await page.getByLabel('Password').fill('ValidPass@123');
  170 |     await page.getByRole('button', { name: 'Create Account' }).click();
  171 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  172 | 
  173 |     // Step 1 — Practice type
  174 |     await expect(page.getByText('How do you practice?')).toBeVisible();
  175 |     await page.getByText('CA Firm').click();
  176 |     // Continue button should now be enabled
  177 |     await page.getByRole('button', { name: 'Continue' }).click();
  178 | 
  179 |     // Step 2 — Firm details
  180 |     await expect(page.getByText('Firm Details')).toBeVisible();
  181 |     await page.getByLabel(/Firm Name/i).fill('Playwright Test Associates');
  182 |     await page.getByLabel(/Your Full Name/i).fill('CA Playwright Tester');
  183 |     await page.getByLabel(/ICAI/i).fill('123456');
  184 |     await page.getByLabel(/Phone/i).fill('9876543210');
  185 |     await page.getByLabel(/City/i).fill('Pune');
  186 |     // State dropdown
  187 |     await page.getByText('Select').click();
  188 |     await page.getByRole('option', { name: 'Maharashtra' }).click();
  189 | 
  190 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  191 | 
  192 |     // Should land on dashboard
  193 |     await expect(page).toHaveURL('/', { timeout: 15_000 });
  194 |     await expect(page.getByText('Dashboard')).toBeVisible();
  195 |   });
  196 | 
  197 |   test('completes Solo Practitioner onboarding', async ({ page }) => {
  198 |     const email = `solo-test-${Date.now()}@playwright-ca.test`;
  199 |     await page.goto('/login');
  200 |     await page.getByText('Create Account').click();
  201 |     await page.getByLabel('Email Address').fill(email);
  202 |     await page.getByLabel('Password').fill('ValidPass@123');
  203 |     await page.getByRole('button', { name: 'Create Account' }).click();
  204 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  205 | 
  206 |     await page.getByText('Solo Practitioner').click();
  207 |     await page.getByRole('button', { name: 'Continue' }).click();
  208 | 
  209 |     // Solo practitioner — NO firm name field
  210 |     await expect(page.getByLabel(/Firm Name/i)).not.toBeVisible();
  211 |     await expect(page.getByLabel(/Your Full Name/i)).toBeVisible();
  212 | 
  213 |     await page.getByLabel(/Your Full Name/i).fill('CA Solo Tester');
  214 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  215 | 
  216 |     await expect(page).toHaveURL('/', { timeout: 15_000 });
  217 |   });
  218 | 
  219 |   test('onboarding requires CA name', async ({ page }) => {
  220 |     const email = `validation-test-${Date.now()}@playwright-ca.test`;
  221 |     await page.goto('/login');
  222 |     await page.getByText('Create Account').click();
  223 |     await page.getByLabel('Email Address').fill(email);
  224 |     await page.getByLabel('Password').fill('ValidPass@123');
  225 |     await page.getByRole('button', { name: 'Create Account' }).click();
  226 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  227 | 
  228 |     await page.getByText('Solo Practitioner').click();
  229 |     await page.getByRole('button', { name: 'Continue' }).click();
  230 | 
  231 |     // Try to save without name
  232 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  233 |     await expectToast(page, /name.*required|required|name/i);
  234 |     // Must stay on onboarding
  235 |     await expect(page).toHaveURL('/onboarding');
  236 |   });
  237 | 
  238 |   test('onboarding Continue button disabled until practice type selected', async ({ page }) => {
  239 |     const email = `btn-test-${Date.now()}@playwright-ca.test`;
  240 |     await page.goto('/login');
  241 |     await page.getByText('Create Account').click();
  242 |     await page.getByLabel('Email Address').fill(email);
  243 |     await page.getByLabel('Password').fill('ValidPass@123');
  244 |     await page.getByRole('button', { name: 'Create Account' }).click();
  245 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  246 | 
  247 |     const continueBtn = page.getByRole('button', { name: 'Continue' });
  248 |     await expect(continueBtn).toBeDisabled();
  249 |     
  250 |     await page.getByText('CA Firm').click();
  251 |     await expect(continueBtn).toBeEnabled();
  252 |   });
```