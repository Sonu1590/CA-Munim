# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Sign Out >> signs out and redirects to login
- Location: e2e\01-auth.spec.ts:328:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('CA Munim')
Expected: visible
Error: strict mode violation: getByText('CA Munim') resolved to 2 elements:
    1) <h1 class="text-2xl font-heading font-bold text-foreground">CA Munim</h1> aka getByRole('heading', { name: 'CA Munim' })
    2) <p class="text-center text-xs text-muted-foreground mt-6">…</p> aka getByText('Your data is secured with row')

Call log:
  - Expect "toBeVisible" with timeout 8000ms
  - waiting for getByText('CA Munim')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications (F8)":
    - list
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "CA Munim" [level=1] [ref=e11]
      - paragraph [ref=e12]: Your digital practice manager
    - generic [ref=e13]:
      - generic [ref=e14]:
        - button "Sign In" [ref=e15] [cursor=pointer]
        - button "Create Account" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]:
          - text: Email Address
          - textbox "Email Address" [ref=e19]:
            - /placeholder: you@yourfirm.com
        - generic [ref=e20]:
          - text: Password
          - generic [ref=e21]:
            - textbox "Password" [ref=e22]:
              - /placeholder: Your password
            - button [ref=e23] [cursor=pointer]:
              - img [ref=e24]
        - button "Sign In" [ref=e27] [cursor=pointer]
      - generic [ref=e28]: or continue with
      - button "Continue with Google" [ref=e29] [cursor=pointer]:
        - img
        - text: Continue with Google
      - button "Forgot password?" [ref=e30] [cursor=pointer]
    - paragraph [ref=e31]:
      - text: Your data is secured with row-level encryption.
      - text: © 2026 CA Munim
```

# Test source

```ts
  232 | 
  233 |   test('onboarding Continue button disabled until practice type selected', async ({ page }) => {
  234 |     const email = `btn-test-${Date.now()}@playwright-ca.test`;
  235 |     await page.goto('/login');
  236 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).first().click();
  237 |     await page.getByLabel('Email Address').fill(email);
  238 |     await page.getByLabel('Password').fill('ValidPass@123');
  239 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  240 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  241 | 
  242 |     const continueBtn = page.getByRole('button', { name: 'Continue' });
  243 |     await expect(continueBtn).toBeDisabled();
  244 |     
  245 |     await page.getByText('CA Firm').click();
  246 |     await expect(continueBtn).toBeEnabled();
  247 |   });
  248 | 
  249 |   test('Back button on step 2 returns to step 1', async ({ page }) => {
  250 |     const email = `back-test-${Date.now()}@playwright-ca.test`;
  251 |     await page.goto('/login');
  252 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).first().click();
  253 |     await page.getByLabel('Email Address').fill(email);
  254 |     await page.getByLabel('Password').fill('ValidPass@123');
  255 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  256 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  257 | 
  258 |     await page.getByText('CA Firm').click();
  259 |     await page.getByRole('button', { name: 'Continue' }).click();
  260 |     await expect(page.getByText('Firm Details')).toBeVisible();
  261 | 
  262 |     await page.getByRole('button', { name: 'Back' }).click();
  263 |     await expect(page.getByText('How do you practice?')).toBeVisible();
  264 |   });
  265 | 
  266 |   test('completed onboarding — refresh does not show onboarding again', async ({ page }) => {
  267 |     await signIn(page);
  268 |     await page.reload();
  269 |     await expect(page).toHaveURL('/');
  270 |     // Must NOT redirect to onboarding
  271 |     await expect(page).not.toHaveURL('/onboarding');
  272 |   });
  273 | });
  274 | 
  275 | // ── Protected Routes ─────────────────────────────────────────────────────────
  276 | 
  277 | test.describe('Protected Routes', () => {
  278 |   const protectedRoutes = [
  279 |     '/clients',
  280 |     '/tasks',
  281 |     '/documents',
  282 |     '/whatsapp',
  283 |     '/billing',
  284 |     '/reports',
  285 |     '/settings',
  286 |     '/penalty-calculator',
  287 |   ];
  288 | 
  289 |   for (const route of protectedRoutes) {
  290 |     test(`${route} redirects unauthenticated user to login`, async ({ page }) => {
  291 |       await page.goto(route);
  292 |       await expect(page).toHaveURL('/login', { timeout: 8_000 });
  293 |     });
  294 |   }
  295 | 
  296 |   test('/upload/:token is public — no redirect to login', async ({ page }) => {
  297 |     await page.goto('/upload/some-fake-token-12345');
  298 |     // Should NOT redirect to login — shows upload portal (even if token is invalid)
  299 |     await expect(page).not.toHaveURL('/login');
  300 |     // Should show an error about invalid token, not a login form
  301 |     await expect(page.getByText(/invalid|expired|not found/i).or(
  302 |       page.getByText(/upload|document/i)
  303 |     )).toBeVisible({ timeout: 8_000 });
  304 |   });
  305 | });
  306 | 
  307 | // ── Session Persistence ──────────────────────────────────────────────────────
  308 | 
  309 | test.describe('Session Persistence', () => {
  310 |   test('stays logged in after page refresh', async ({ page }) => {
  311 |     await signIn(page);
  312 |     await page.reload();
  313 |     await expect(page).toHaveURL('/');
  314 |     await expect(page).not.toHaveURL('/login');
  315 |   });
  316 | 
  317 |   test('stays logged in after navigating to a route directly', async ({ page }) => {
  318 |     await signIn(page);
  319 |     await page.goto('/clients');
  320 |     await expect(page.getByText('Clients')).toBeVisible({ timeout: 10_000 });
  321 |     await expect(page).not.toHaveURL('/login');
  322 |   });
  323 | });
  324 | 
  325 | // ── Sign Out ─────────────────────────────────────────────────────────────────
  326 | 
  327 | test.describe('Sign Out', () => {
  328 |   test('signs out and redirects to login', async ({ page }) => {
  329 |     await signIn(page);
  330 |     await signOut(page);
  331 |     await expect(page).toHaveURL('/login');
> 332 |     await expect(page.getByText('CA Munim')).toBeVisible();
      |                                              ^ Error: expect(locator).toBeVisible() failed
  333 |   });
  334 | 
  335 |   test('cannot access protected route after signing out', async ({ page }) => {
  336 |     await signIn(page);
  337 |     await signOut(page);
  338 |     await page.goto('/clients');
  339 |     await expect(page).toHaveURL('/login', { timeout: 8_000 });
  340 |   });
  341 | });
  342 | 
  343 | // ── Forgot Password ──────────────────────────────────────────────────────────
  344 | 
  345 | test.describe('Forgot Password', () => {
  346 |   test('shows error if email not entered before clicking forgot password', async ({ page }) => {
  347 |     await page.goto('/login');
  348 |     await page.getByText('Forgot password?').click();
  349 |     await expectToast(page, /email|enter/i);
  350 |   });
  351 | 
  352 |   test('shows success message when valid email entered', async ({ page }) => {
  353 |     await page.goto('/login');
  354 |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  355 |     await page.getByText('Forgot password?').click();
  356 |     await expectToast(page, /sent|check.*inbox|email/i);
  357 |   });
  358 | });
  359 | 
```