# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Sign Up >> shows create account form elements
- Location: e2e\01-auth.spec.ts:119:3

# Error details

```
Test timeout of 30000ms exceeded while running "beforeEach" hook.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('form').getByRole('button', { name: /^create account$/i }).first()

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications (F8)":
    - list
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "CA Munim" [level=1] [ref=e11]
      - paragraph [ref=e12]: Your digital practice manager
    - generic [ref=e13]:
      - generic [ref=e14]:
        - button "Sign In" [ref=e15] [cursor=pointer]
        - button "Create Account" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]:
          - text: Email Address
          - textbox "Email Address" [ref=e19]:
            - /placeholder: you@yourfirm.com
        - generic [ref=e20]:
          - text: Password
          - generic [ref=e21]:
            - textbox "Password" [ref=e22]:
              - /placeholder: Your password
            - button [ref=e23] [cursor=pointer]:
              - img [ref=e24]
        - button "Sign In" [ref=e27] [cursor=pointer]
      - generic [ref=e28]: or continue with
      - button "Continue with Google" [ref=e29] [cursor=pointer]:
        - img
        - text: Continue with Google
      - button "Forgot password?" [ref=e30] [cursor=pointer]
    - paragraph [ref=e31]:
      - text: Your data is secured with row-level encryption.
      - text: © 2026 CA Munim
```

# Test source

```ts
  16  | 
  17  | // ── Sign In ──────────────────────────────────────────────────────────────────
  18  | 
  19  | test.describe('Sign In', () => {
  20  |   test.beforeEach(async ({ page }) => {
  21  |     await page.goto('/login');
  22  |     await expect(page.getByText('CA Munim').first()).toBeVisible();
  23  |   });
  24  | 
  25  |   test('shows login page with correct elements', async ({ page }) => {
  26  |     await expect(page.getByText('Sign In')).toBeVisible();
  27  |     await expect(page.getByText('Create Account')).toBeVisible();
  28  |     await expect(page.getByLabel('Email Address')).toBeVisible();
  29  |     await expect(page.getByLabel('Password')).toBeVisible();
  30  |     await expect(page.locator('form').getByRole('button', {name: /^sign in$/i,})).toBeVisible();
  31  |     await expect(page.getByText('Forgot password?')).toBeVisible();
  32  |   });
  33  | 
  34  |   test('signs in with valid credentials', async ({ page }) => {
  35  |     await signIn(page);
  36  |     await expect(page).toHaveURL('/');
  37  |   });
  38  | 
  39  |   test('shows error for wrong password', async ({ page }) => {
  40  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  41  |     await page.getByLabel('Password').fill('WrongPassword123!');
  42  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  43  |     await expectToast(page, /incorrect|invalid|wrong|credentials/i);
  44  |     // Must stay on login page
  45  |     await expect(page).toHaveURL('/login');
  46  |   });
  47  | 
  48  |   test('shows error for invalid email format', async ({ page }) => {
  49  |     await page.getByLabel('Email Address').fill('notanemail');
  50  |     await page.getByLabel('Password').fill('SomePassword123');
  51  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  52  |     // Browser native validation or toast
  53  |     const emailInput = page.getByLabel('Email Address');
  54  |     const validationMessage = await emailInput.evaluate((el: HTMLInputElement) => el.validationMessage);
  55  |     expect(validationMessage).toBeTruthy(); // browser validates email format
  56  |   });
  57  | 
  58  |   test('shows error for empty email', async ({ page }) => {
  59  |     await page.getByLabel('Password').fill('SomePassword123');
  60  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  61  |     await expectToast(page, /email|password|required/i);
  62  |   });
  63  | 
  64  |   test('shows error for empty password', async ({ page }) => {
  65  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  66  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  67  |     await expectToast(page, /email|password|required/i);
  68  |   });
  69  | 
  70  |   test('shows loading state while signing in', async ({ page }) => {
  71  |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  72  |     await page.getByLabel('Password').fill(TEST_USER.password);
  73  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  74  |     // Button should show loading state briefly
  75  |     const button = page.getByRole('button', { name: /sign in|signing/i });
  76  |     // Either shows a spinner or disables
  77  |     await expect(button).toBeDisabled().catch(() => {}); // may be too fast
  78  |   });
  79  | 
  80  |   test.skip('unverified email shows helpful error with resend option', async ({ page }) => {
  81  |     // This test requires a known unverified email in your test environment
  82  |     // If Supabase email verification is disabled, skip this
  83  |     await page.getByLabel('Email Address').fill('unverified@test.com');
  84  |     await page.getByLabel('Password').fill('TestPass123!');
  85  |     await page.locator('form').getByRole('button', { name: /^sign.?in$/i }).click();
  86  |     await expectToast(page, /verify|confirm|email/i);
  87  |     // Should offer resend option
  88  |     await expect(page.getByRole('button', { name: /resend/i })).toBeVisible();
  89  |   });
  90  | 
  91  |   test.skip('redirects to original page after login', async ({ page }) => {
  92  |     // Try to access a protected route
  93  |     await page.goto('/clients');
  94  |     // Should redirect to login
  95  |     await expect(page).toHaveURL('/login');
  96  |     // Sign in
  97  |     await signIn(page);
  98  |     // Note: redirects to / not /clients in current implementation
  99  |     // Update this if redirect-after-login is implemented
  100 |     await expect(page).toHaveURL(/\//);
  101 |   });
  102 | 
  103 |   test.skip('already logged-in user is redirected away from login', async ({ page }) => {
  104 |     await signIn(page);
  105 |     await page.goto('/login');
  106 |     // Should redirect to dashboard, not show login page
  107 |     await expect(page).toHaveURL('/');
  108 |   });
  109 | });
  110 | 
  111 | // ── Sign Up ──────────────────────────────────────────────────────────────────
  112 | 
  113 | test.describe('Sign Up', () => {
  114 |   test.beforeEach(async ({ page }) => {
  115 |     await page.goto('/login');
> 116 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).first().click();
      |                                                                                           ^ Error: locator.click: Test timeout of 30000ms exceeded.
  117 |   });
  118 | 
  119 |   test('shows create account form elements', async ({ page }) => {
  120 |     await expect(page.getByLabel('Email Address')).toBeVisible();
  121 |     await expect(page.getByLabel('Password')).toBeVisible();
  122 |     await expect(page.locator('form').getByRole('button', { name: /^create account$/i })).toBeVisible();
  123 |   });
  124 | 
  125 |   test('shows error for password too short', async ({ page }) => {
  126 |     await page.getByLabel('Email Address').fill('newuser@test.com');
  127 |     await page.getByLabel('Password').fill('short');
  128 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  129 |     await expectToast(page, /8 character|password.*short|too short/i);
  130 |   });
  131 | 
  132 |   test('shows error for duplicate email', async ({ page }) => {
  133 |     // Try to sign up with an already-registered email
  134 |     await page.getByLabel('Email Address').fill(TEST_USER.email);
  135 |     await page.getByLabel('Password').fill('TestPassword@123');
  136 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  137 |     await expectToast(page, /already|exists|registered/i);
  138 |     // Must stay on login page
  139 |     await expect(page).toHaveURL('/login');
  140 |   });
  141 | 
  142 |   test('valid signup redirects to onboarding', async ({ page }) => {
  143 |     // Use a timestamp-based unique email to avoid conflicts
  144 |     const uniqueEmail = `test-${Date.now()}@playwright-ca.test`;
  145 |     
  146 |     await page.getByLabel('Email Address').fill(uniqueEmail);
  147 |     await page.getByLabel('Password').fill('ValidPass@123');
  148 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  149 | 
  150 |     // Should go to onboarding
  151 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  152 |     await expect(page.getByText('Welcome to CA Munim')).toBeVisible();
  153 |   });
  154 | });
  155 | 
  156 | // ── Onboarding ───────────────────────────────────────────────────────────────
  157 | 
  158 | test.describe.skip('Onboarding — CA Firm flow', () => {
  159 |   test('completes CA Firm onboarding', async ({ page }) => {
  160 |     // Sign up fresh user
  161 |     const email = `firm-test-${Date.now()}@playwright-ca.test`;
  162 |     await page.goto('/login');
  163 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).first().click();
  164 |     await page.getByLabel('Email Address').fill(email);
  165 |     await page.getByLabel('Password').fill('ValidPass@123');
  166 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  167 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  168 | 
  169 |     // Step 1 — Practice type
  170 |     await expect(page.getByText('How do you practice?')).toBeVisible();
  171 |     await page.getByText('CA Firm').click();
  172 |     // Continue button should now be enabled
  173 |     await page.getByRole('button', { name: 'Continue' }).click();
  174 | 
  175 |     // Step 2 — Firm details
  176 |     await expect(page.getByText('Firm Details')).toBeVisible();
  177 |     await page.getByLabel(/Firm Name/i).fill('Playwright Test Associates');
  178 |     await page.getByLabel(/Your Full Name/i).fill('CA Playwright Tester');
  179 |     await page.getByLabel(/ICAI/i).fill('123456');
  180 |     await page.getByLabel(/Phone/i).fill('9876543210');
  181 |     await page.getByLabel(/City/i).fill('Pune');
  182 |     // State dropdown
  183 |     await page.getByText('Select').click();
  184 |     await page.getByRole('option', { name: 'Maharashtra' }).click();
  185 | 
  186 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  187 | 
  188 |     // Should land on dashboard
  189 |     await expect(page).toHaveURL('/', { timeout: 15_000 });
  190 |   });
  191 | 
  192 |   test('completes Solo Practitioner onboarding', async ({ page }) => {
  193 |     const email = `solo-test-${Date.now()}@playwright-ca.test`;
  194 |     await page.goto('/login');
  195 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).first().click();
  196 |     await page.getByLabel('Email Address').fill(email);
  197 |     await page.getByLabel('Password').fill('ValidPass@123');
  198 |     await page.locator('form').getByRole('button', { name: /^create account$/i }).click();
  199 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  200 | 
  201 |     await page.getByText('Solo Practitioner').click();
  202 |     await page.getByRole('button', { name: 'Continue' }).click();
  203 | 
  204 |     // Solo practitioner — NO firm name field
  205 |     await expect(page.getByLabel(/Firm Name/i)).not.toBeVisible();
  206 |     await expect(page.getByLabel(/Your Full Name/i)).toBeVisible();
  207 | 
  208 |     await page.getByLabel(/Your Full Name/i).fill('CA Solo Tester');
  209 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  210 | 
  211 |     await expect(page).toHaveURL('/', { timeout: 15_000 });
  212 |   });
  213 | 
  214 |   test('onboarding requires CA name', async ({ page }) => {
  215 |     const email = `validation-test-${Date.now()}@playwright-ca.test`;
  216 |     await page.goto('/login');
```