# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Sign Out >> cannot access protected route after signing out
- Location: e2e\01-auth.spec.ts:341:3

# Error details

```
Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Sign In' }) resolved to 2 elements:
    1) <button type="button" class="flex-1 text-sm font-medium py-1.5 rounded-md transition-colors bg-primary text-primary-foreground">Sign In</button> aka getByRole('button', { name: 'Sign In' }).first()
    2) <button type="submit" class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 px-4 py-2 w-full h-11 bg-accent hover:bg-accent/90 text-white font-semibold">Sign In</button> aka locator('form').getByRole('button', { name: 'Sign In' })

Call log:
  - waiting for getByRole('button', { name: 'Sign In' })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications (F8)":
    - list
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "CA Munim" [level=1] [ref=e11]
      - paragraph [ref=e12]: Your digital practice manager
    - generic [ref=e13]:
      - generic [ref=e14]:
        - button "Sign In" [ref=e15] [cursor=pointer]
        - button "Create Account" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]:
          - text: Email Address
          - textbox "Email Address" [ref=e19]:
            - /placeholder: you@yourfirm.com
            - text: sonusingh1590@gmail,com
        - generic [ref=e20]:
          - text: Password
          - generic [ref=e21]:
            - textbox "Password" [active] [ref=e22]:
              - /placeholder: Your password
              - text: Camunim#1590
            - button [ref=e23] [cursor=pointer]:
              - img [ref=e24]
        - button "Sign In" [ref=e27] [cursor=pointer]
      - generic [ref=e28]: or continue with
      - button "Continue with Google" [ref=e29] [cursor=pointer]:
        - img
        - text: Continue with Google
      - button "Forgot password?" [ref=e30] [cursor=pointer]
    - paragraph [ref=e31]:
      - text: Your data is secured with row-level encryption.
      - text: © 2026 CA Munim
```

# Test source

```ts
  1   | /**
  2   |  * e2e/helpers/auth.ts
  3   |  * Shared auth helpers used across all test suites
  4   |  */
  5   | import { Page, expect } from '@playwright/test';
  6   | 
  7   | // ── Test credentials ─────────────────────────────────────────────────────────
  8   | // Use a dedicated test account — NEVER use your real CA account
  9   | export const TEST_USER = {
  10  |   email: process.env.TEST_USER_EMAIL ?? 'sonusingh1590@gmail,com',
  11  |   password: process.env.TEST_USER_PASSWORD ?? 'Camunim#1590',
  12  | };
  13  | 
  14  | // Test client data — used across multiple suites
  15  | export const TEST_CLIENT = {
  16  |   name: 'Playwright Test Client',
  17  |   pan: 'ABCPT1234K',
  18  |   phone: '9876543210',
  19  |   email: 'testclient@playwright.test',
  20  |   city: 'Pune',
  21  |   state: 'Maharashtra',
  22  |   type: 'Individual',
  23  | };
  24  | 
  25  | export const TEST_CLIENT_2 = {
  26  |   name: 'Playwright Firm Test',
  27  |   pan: 'AABCP5678M',
  28  |   phone: '9123456789',
  29  |   email: 'firmtest@playwright.test',
  30  |   city: 'Mumbai',
  31  |   state: 'Maharashtra',
  32  |   type: 'Private Ltd',
  33  | };
  34  | 
  35  | export const TEST_TASK = {
  36  |   type: 'GSTR-3B',
  37  |   financialYear: 'FY 2025-26',
  38  |   period: 'April',
  39  |   priority: 'high',
  40  | };
  41  | 
  42  | export const TEST_INVOICE = {
  43  |   description: 'ITR Filing FY 2025-26',
  44  |   amount: '5000',
  45  | };
  46  | 
  47  | // ── Auth helpers ─────────────────────────────────────────────────────────────
  48  | 
  49  | /**
  50  |  * Sign in and wait for dashboard to load.
  51  |  * Call this at the start of any test that needs auth.
  52  |  */
  53  | export async function signIn(page: Page, email = TEST_USER.email, password = TEST_USER.password) {
  54  |   await page.goto('/login');
  55  |   await expect(page.getByRole('heading', { name: 'CA Munim' })).toBeVisible();
  56  | 
  57  |   // Fill credentials
  58  |   await page.getByLabel('Email Address').fill(email);
  59  |   await page.getByLabel('Password').fill(password);
> 60  |   await page.getByRole('button', { name: 'Sign In' }).click();
      |                                                       ^ Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Sign In' }) resolved to 2 elements:
  61  | 
  62  |   // Wait for dashboard — confirms auth + onboarding complete
  63  |   await expect(page).toHaveURL('/', { timeout: 15_000 });
  64  |   await expect(page.getByText('Dashboard')).toBeVisible({ timeout: 10_000 });
  65  | }
  66  | 
  67  | /**
  68  |  * Sign out from the app.
  69  |  */
  70  | export async function signOut(page: Page) {
  71  |   // Click logout button in sidebar (LogOut icon)
  72  |   const logoutBtn = page.locator('[title="Sign out"]').or(
  73  |     page.getByRole('button', { name: /sign out|logout/i })
  74  |   );
  75  |   await logoutBtn.click();
  76  |   await expect(page).toHaveURL('/login', { timeout: 8_000 });
  77  | }
  78  | 
  79  | /**
  80  |  * Navigate to a page and wait for it to be ready.
  81  |  */
  82  | export async function goTo(page: Page, path: string, waitForText?: string) {
  83  |   await page.goto(path);
  84  |   if (waitForText) {
  85  |     await expect(page.getByText(waitForText).first()).toBeVisible({ timeout: 10_000 });
  86  |   }
  87  | }
  88  | 
  89  | /**
  90  |  * Wait for a toast notification to appear.
  91  |  */
  92  | export async function expectToast(page: Page, text: string | RegExp, timeout = 8_000) {
  93  |   const toast = page.locator('[data-sonner-toast]')
  94  |     .or(page.locator('[role="status"]'))
  95  |     .filter({ hasText: text });
  96  |   await expect(toast).toBeVisible({ timeout });
  97  | }
  98  | 
  99  | /**
  100 |  * Select a value in a shadcn/radix Select component.
  101 |  * Clicks the trigger, then clicks the option.
  102 |  */
  103 | export async function selectOption(page: Page, triggerLabel: string, optionText: string) {
  104 |   await page.getByLabel(triggerLabel).click();
  105 |   // Radix Select renders options in a portal
  106 |   await page.getByRole('option', { name: optionText }).click();
  107 | }
  108 | 
  109 | /**
  110 |  * Open a Select by its placeholder text.
  111 |  */
  112 | export async function selectByPlaceholder(page: Page, placeholder: string, optionText: string) {
  113 |   await page.getByText(placeholder).click();
  114 |   await page.getByRole('option', { name: optionText }).click();
  115 | }
  116 | 
  117 | /**
  118 |  * Fill a date input field (input type="date").
  119 |  * Uses the YYYY-MM-DD format that HTML date inputs expect.
  120 |  */
  121 | export async function fillDate(page: Page, label: string, dateStr: string) {
  122 |   const input = page.getByLabel(label);
  123 |   await input.fill(dateStr);
  124 |   await input.press('Tab');
  125 | }
  126 | 
  127 | /**
  128 |  * Check that the page shows a loading spinner and it eventually disappears.
  129 |  */
  130 | export async function waitForLoadingToFinish(page: Page) {
  131 |   const spinner = page.locator('.animate-spin').first();
  132 |   if (await spinner.isVisible()) {
  133 |     await expect(spinner).not.toBeVisible({ timeout: 15_000 });
  134 |   }
  135 | }
  136 | 
  137 | /**
  138 |  * Get the current count from a badge (e.g. "Clients 47")
  139 |  */
  140 | export async function getBadgeCount(page: Page, label: string): Promise<number> {
  141 |   const badge = page.locator('text=' + label).locator('..').locator('span.badge, span[class*="badge"]');
  142 |   const text = await badge.textContent();
  143 |   return parseInt(text ?? '0', 10);
  144 | }
  145 | 
```