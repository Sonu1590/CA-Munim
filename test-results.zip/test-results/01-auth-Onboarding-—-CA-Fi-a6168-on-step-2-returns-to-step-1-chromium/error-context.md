# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-auth.spec.ts >> Onboarding — CA Firm flow >> Back button on step 2 returns to step 1
- Location: e2e\01-auth.spec.ts:254:3

# Error details

```
Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Create Account' }) resolved to 2 elements:
    1) <button type="button" class="flex-1 text-sm font-medium py-1.5 rounded-md transition-colors bg-primary text-primary-foreground">Create Account</button> aka getByRole('button', { name: 'Create Account' }).first()
    2) <button type="submit" class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 px-4 py-2 w-full h-11 bg-accent hover:bg-accent/90 text-white font-semibold">Create Account</button> aka locator('form').getByRole('button', { name: 'Create Account' })

Call log:
  - waiting for getByRole('button', { name: 'Create Account' })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications (F8)":
    - list
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - img [ref=e7]
      - heading "CA Munim" [level=1] [ref=e11]
      - paragraph [ref=e12]: Your digital practice manager
    - generic [ref=e13]:
      - generic [ref=e14]:
        - button "Sign In" [ref=e15] [cursor=pointer]
        - button "Create Account" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]:
          - text: Your Name *
          - textbox "Your Name *" [ref=e19]:
            - /placeholder: CA Priya Sharma
        - generic [ref=e20]:
          - text: Firm Name
          - textbox "Firm Name" [ref=e21]:
            - /placeholder: Sharma & Associates
        - generic [ref=e22]:
          - text: ICAI Membership Number
          - textbox "ICAI Membership Number" [ref=e23]:
            - /placeholder: "123456"
        - generic [ref=e24]:
          - text: Email Address
          - textbox "Email Address" [ref=e25]:
            - /placeholder: you@yourfirm.com
            - text: back-test-1780929444855@playwright-ca.test
        - generic [ref=e26]:
          - text: Password
          - generic [ref=e27]:
            - textbox "Password" [active] [ref=e28]:
              - /placeholder: Min. 8 characters
              - text: ValidPass@123
            - button [ref=e29] [cursor=pointer]:
              - img [ref=e30]
        - button "Create Account" [ref=e33] [cursor=pointer]
      - generic [ref=e34]: or continue with
      - button "Continue with Google" [ref=e35] [cursor=pointer]:
        - img
        - text: Continue with Google
    - paragraph [ref=e36]:
      - text: Your data is secured with row-level encryption.
      - text: © 2026 CA Munim
```

# Test source

```ts
  160 | // ── Onboarding ───────────────────────────────────────────────────────────────
  161 | 
  162 | test.describe('Onboarding — CA Firm flow', () => {
  163 |   test('completes CA Firm onboarding', async ({ page }) => {
  164 |     // Sign up fresh user
  165 |     const email = `firm-test-${Date.now()}@playwright-ca.test`;
  166 |     await page.goto('/login');
  167 |     await page.getByText('Create Account').click();
  168 |     await page.getByLabel('Email Address').fill(email);
  169 |     await page.getByLabel('Password').fill('ValidPass@123');
  170 |     await page.getByRole('button', { name: 'Create Account' }).click();
  171 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  172 | 
  173 |     // Step 1 — Practice type
  174 |     await expect(page.getByText('How do you practice?')).toBeVisible();
  175 |     await page.getByText('CA Firm').click();
  176 |     // Continue button should now be enabled
  177 |     await page.getByRole('button', { name: 'Continue' }).click();
  178 | 
  179 |     // Step 2 — Firm details
  180 |     await expect(page.getByText('Firm Details')).toBeVisible();
  181 |     await page.getByLabel(/Firm Name/i).fill('Playwright Test Associates');
  182 |     await page.getByLabel(/Your Full Name/i).fill('CA Playwright Tester');
  183 |     await page.getByLabel(/ICAI/i).fill('123456');
  184 |     await page.getByLabel(/Phone/i).fill('9876543210');
  185 |     await page.getByLabel(/City/i).fill('Pune');
  186 |     // State dropdown
  187 |     await page.getByText('Select').click();
  188 |     await page.getByRole('option', { name: 'Maharashtra' }).click();
  189 | 
  190 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  191 | 
  192 |     // Should land on dashboard
  193 |     await expect(page).toHaveURL('/', { timeout: 15_000 });
  194 |     await expect(page.getByText('Dashboard')).toBeVisible();
  195 |   });
  196 | 
  197 |   test('completes Solo Practitioner onboarding', async ({ page }) => {
  198 |     const email = `solo-test-${Date.now()}@playwright-ca.test`;
  199 |     await page.goto('/login');
  200 |     await page.getByText('Create Account').click();
  201 |     await page.getByLabel('Email Address').fill(email);
  202 |     await page.getByLabel('Password').fill('ValidPass@123');
  203 |     await page.getByRole('button', { name: 'Create Account' }).click();
  204 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  205 | 
  206 |     await page.getByText('Solo Practitioner').click();
  207 |     await page.getByRole('button', { name: 'Continue' }).click();
  208 | 
  209 |     // Solo practitioner — NO firm name field
  210 |     await expect(page.getByLabel(/Firm Name/i)).not.toBeVisible();
  211 |     await expect(page.getByLabel(/Your Full Name/i)).toBeVisible();
  212 | 
  213 |     await page.getByLabel(/Your Full Name/i).fill('CA Solo Tester');
  214 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  215 | 
  216 |     await expect(page).toHaveURL('/', { timeout: 15_000 });
  217 |   });
  218 | 
  219 |   test('onboarding requires CA name', async ({ page }) => {
  220 |     const email = `validation-test-${Date.now()}@playwright-ca.test`;
  221 |     await page.goto('/login');
  222 |     await page.getByText('Create Account').click();
  223 |     await page.getByLabel('Email Address').fill(email);
  224 |     await page.getByLabel('Password').fill('ValidPass@123');
  225 |     await page.getByRole('button', { name: 'Create Account' }).click();
  226 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  227 | 
  228 |     await page.getByText('Solo Practitioner').click();
  229 |     await page.getByRole('button', { name: 'Continue' }).click();
  230 | 
  231 |     // Try to save without name
  232 |     await page.getByRole('button', { name: 'Save & Get Started' }).click();
  233 |     await expectToast(page, /name.*required|required|name/i);
  234 |     // Must stay on onboarding
  235 |     await expect(page).toHaveURL('/onboarding');
  236 |   });
  237 | 
  238 |   test('onboarding Continue button disabled until practice type selected', async ({ page }) => {
  239 |     const email = `btn-test-${Date.now()}@playwright-ca.test`;
  240 |     await page.goto('/login');
  241 |     await page.getByText('Create Account').click();
  242 |     await page.getByLabel('Email Address').fill(email);
  243 |     await page.getByLabel('Password').fill('ValidPass@123');
  244 |     await page.getByRole('button', { name: 'Create Account' }).click();
  245 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  246 | 
  247 |     const continueBtn = page.getByRole('button', { name: 'Continue' });
  248 |     await expect(continueBtn).toBeDisabled();
  249 |     
  250 |     await page.getByText('CA Firm').click();
  251 |     await expect(continueBtn).toBeEnabled();
  252 |   });
  253 | 
  254 |   test('Back button on step 2 returns to step 1', async ({ page }) => {
  255 |     const email = `back-test-${Date.now()}@playwright-ca.test`;
  256 |     await page.goto('/login');
  257 |     await page.getByText('Create Account').click();
  258 |     await page.getByLabel('Email Address').fill(email);
  259 |     await page.getByLabel('Password').fill('ValidPass@123');
> 260 |     await page.getByRole('button', { name: 'Create Account' }).click();
      |                                                                ^ Error: locator.click: Error: strict mode violation: getByRole('button', { name: 'Create Account' }) resolved to 2 elements:
  261 |     await expect(page).toHaveURL('/onboarding', { timeout: 15_000 });
  262 | 
  263 |     await page.getByText('CA Firm').click();
  264 |     await page.getByRole('button', { name: 'Continue' }).click();
  265 |     await expect(page.getByText('Firm Details')).toBeVisible();
  266 | 
  267 |     await page.getByRole('button', { name: 'Back' }).click();
  268 |     await expect(page.getByText('How do you practice?')).toBeVisible();
  269 |   });
  270 | 
  271 |   test('completed onboarding — refresh does not show onboarding again', async ({ page }) => {
  272 |     await signIn(page);
  273 |     await page.reload();
  274 |     await expect(page).toHaveURL('/');
  275 |     await expect(page.getByText('Dashboard')).toBeVisible();
  276 |     // Must NOT redirect to onboarding
  277 |     await expect(page).not.toHaveURL('/onboarding');
  278 |   });
  279 | });
  280 | 
  281 | // ── Protected Routes ─────────────────────────────────────────────────────────
  282 | 
  283 | test.describe('Protected Routes', () => {
  284 |   const protectedRoutes = [
  285 |     '/clients',
  286 |     '/tasks',
  287 |     '/documents',
  288 |     '/whatsapp',
  289 |     '/billing',
  290 |     '/reports',
  291 |     '/settings',
  292 |     '/penalty-calculator',
  293 |   ];
  294 | 
  295 |   for (const route of protectedRoutes) {
  296 |     test(`${route} redirects unauthenticated user to login`, async ({ page }) => {
  297 |       await page.goto(route);
  298 |       await expect(page).toHaveURL('/login', { timeout: 8_000 });
  299 |     });
  300 |   }
  301 | 
  302 |   test('/upload/:token is public — no redirect to login', async ({ page }) => {
  303 |     await page.goto('/upload/some-fake-token-12345');
  304 |     // Should NOT redirect to login — shows upload portal (even if token is invalid)
  305 |     await expect(page).not.toHaveURL('/login');
  306 |     // Should show an error about invalid token, not a login form
  307 |     await expect(page.getByText(/invalid|expired|not found/i).or(
  308 |       page.getByText(/upload|document/i)
  309 |     )).toBeVisible({ timeout: 8_000 });
  310 |   });
  311 | });
  312 | 
  313 | // ── Session Persistence ──────────────────────────────────────────────────────
  314 | 
  315 | test.describe('Session Persistence', () => {
  316 |   test('stays logged in after page refresh', async ({ page }) => {
  317 |     await signIn(page);
  318 |     await page.reload();
  319 |     await expect(page.getByText('Dashboard')).toBeVisible({ timeout: 10_000 });
  320 |     await expect(page).not.toHaveURL('/login');
  321 |   });
  322 | 
  323 |   test('stays logged in after navigating to a route directly', async ({ page }) => {
  324 |     await signIn(page);
  325 |     await page.goto('/clients');
  326 |     await expect(page.getByText('Clients')).toBeVisible({ timeout: 10_000 });
  327 |     await expect(page).not.toHaveURL('/login');
  328 |   });
  329 | });
  330 | 
  331 | // ── Sign Out ─────────────────────────────────────────────────────────────────
  332 | 
  333 | test.describe('Sign Out', () => {
  334 |   test('signs out and redirects to login', async ({ page }) => {
  335 |     await signIn(page);
  336 |     await signOut(page);
  337 |     await expect(page).toHaveURL('/login');
  338 |     await expect(page.getByRole('heading', { name: 'CA Munim' })).toBeVisible();
  339 |   });
  340 | 
  341 |   test('cannot access protected route after signing out', async ({ page }) => {
  342 |     await signIn(page);
  343 |     await signOut(page);
  344 |     await page.goto('/clients');
  345 |     await expect(page).toHaveURL('/login', { timeout: 8_000 });
  346 |   });
  347 | });
  348 | 
  349 | // ── Forgot Password ──────────────────────────────────────────────────────────
  350 | 
  351 | test.describe('Forgot Password', () => {
  352 |   test('shows error if email not entered before clicking forgot password', async ({ page }) => {
  353 |     await page.goto('/login');
  354 |     await page.getByText('Forgot password?').click();
  355 |     await expectToast(page, /email|enter/i);
  356 |   });
  357 | 
  358 |   test('shows success message when valid email entered', async ({ page }) => {
  359 |     await page.goto('/login');
  360 |     await page.getByLabel('Email Address').fill(TEST_USER.email);
```